class ApiUrls {
  // Reemplaza estos valores por tus endpoints de API Gateway
  static const register = 'https://REPLACE_WITH_YOUR_API/register';
  static const verify = 'https://REPLACE_WITH_YOUR_API/verify';
}
